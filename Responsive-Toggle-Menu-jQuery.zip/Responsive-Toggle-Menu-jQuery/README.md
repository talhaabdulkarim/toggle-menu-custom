# Responsive-Menu
A very simple responsive menu

## Demo
[Demo](https://carry0987.github.io/Responsive-Menu/)

## Screenshot
Desktop :<br />
![](http://i.imgur.com/clwqTaZ.jpg?1)<br />
Mobile :<br />

![](http://i.imgur.com/TW1EXSf.jpg?1)
